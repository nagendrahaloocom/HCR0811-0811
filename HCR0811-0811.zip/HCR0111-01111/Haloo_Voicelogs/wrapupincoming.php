<?php
$phone_number = $_REQUEST['phone'];
$callid = $_REQUEST['callid'];
$date = date("Y-m-d H:i:s");

$er = substr($phone_number,-10);

$conn = mysqli_connect("localhost","root","Hal0o(0m@72427242","asterisk");

$lli = "%".$phone_number."%";
$rtt = mysqli_query($conn,"select filename from recording_log where filename like '$lli' order by recording_id desc limit 1");
$riu = mysqli_fetch_array($rtt);

$monitorfile = "/var/spool/asterisk/monitor/".$riu['filename']."-in.wav";
$custfile = "/home/nag/".$riu['filename']."-cust.wav";

exec("/usr/bin/chmod 777 -R /var/run/asterisk/asterisk.ctl");
if(($phone_number !='')&&(substr($callid,0,1)=='M')){
$dd = exec("/usr/sbin/asterisk -rx 'sip show channels' | grep $er");


if($dd!=''){
if(strlen($phone_number) == 10){
mysqli_query($conn,"update vicidial_log set callid='$callid' where phone_number='$phone_number' order by call_date desc limit 1");}
else{

mysqli_query($conn,"update vicidial_closer_log set callid='$callid' where phone_number='$phone_number' order by call_date desc limit 1");}
exit;
}
}

if (file_exists($custfile)) {
} else {
exec("/usr/bin/cp -r $monitorfile $custfile");}

 
 if(strlen($phone_number) == 10){

            $sql = "update vicidial_log set wraptime=now(),callid='$callid' where phone_number='$phone_number' order by call_date desc limit 1";
                    }else{
            $sql = "update vicidial_closer_log set wraptime=now(),callid='$callid' where phone_number='$phone_number' order by call_date desc limit 1";
                    }
                     mysqli_query($conn,$sql);

if(substr($callid,0,1)=='M'){


$sqlr = "update vicidial_log set wraptime=now() where callid='$callid'";
                    }else{
            $sqlr = "update vicidial_closer_log set wraptime=now() where callid='$callid'";
                    }
                    mysqli_query($conn,$sqlr);

$res = mysqli_query($conn,"select wraptime,dispotime from vicidial_log where callid='$callid'");
if(mysqli_num_rows($res)==1){
	$resp = mysqli_fetch_array($res);
        $wraptime = strtotime($resp['wraptime']);$dispotime = strtotime($resp['dispotime']);
        if(($dispotime == $wraptime)||($dispotime < $wraptime)){mysqli_query($conn,"update vicidial_log set dispo_sec='' where callid='$callid'");}}

$resa = mysqli_query($conn,"select wraptime,dispotime from vicidial_closer_log where callid='$callid'");
if(mysqli_num_rows($resa)==1){
        $resp = mysqli_fetch_array($resa);
        $wraptime = strtotime($resp['wraptime']);$dispotime = strtotime($resp['dispotime']);
        if(($dispotime == $wraptime)||($dispotime < $wraptime)){mysqli_query($conn,"update vicidial_closer_log set dispo_sec='' where callid='$callid'");}}
    

?>
