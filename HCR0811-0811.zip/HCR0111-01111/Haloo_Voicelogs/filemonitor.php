<?php
$audioin = "/var/spool/asterisk/monitor/".$_REQUEST['audio']."-in.wav";
$audioout = "/var/spool/asterisk/monitor/".$_REQUEST['audio']."-out.wav";
$audiocust = "/home/nag/".$_REQUEST['audio']."-cust.wav";
$dir = "/home/nag/".$_REQUEST['audio'].".wav";

$gsm = substr($dir,0,-3)."gsm";
$tr = '';

if (file_exists($audiocust)) {
$kk="";
get_all_directory_and_files($dir,$gsm,$audioin,$audiocust,$kk);
} else {
$kk="lo";
get_all_directory_and_files($dir,$gsm,$tr,$audioin,$kk);
}


 function get_all_directory_and_files($dir,$gsm,$audioin,$audiocust,$kk){
       $conn = mysqli_connect("localhost","root","Hal0o(0m@72427242","asterisk");
                
                
                exec("/usr/bin/sox --ignore-length $audiocust $gsm");
                $file = $gsm;
                            $filename = $file;
                            echo $duration=wavDur($filename);
                   $exp = explode("_",$dir);$pf = $exp[1];

                    if(strlen($pf) == 10){
                    
                    $sql = "update vicidial_log set haloo_talk = '$duration',dispotime=now(),dispo_sec=time_to_sec(timediff(dispotime,wraptime)),wrap='yes' where phone_number='$pf' order by call_date desc limit 1";
                    }else{
                    $sql = "update vicidial_closer_log set haloo_talk = '$duration',dispotime=now(),dispo_sec=time_to_sec(timediff(dispotime,wraptime)),wrap='yes' where phone_number='$pf' order by call_date desc limit 1";
                    }

                    
                    $result = mysqli_query($conn,$sql);

                  //if($kk == 'lo'){
                   $uniqconf = uniqid();


        $uniq1 = "/tmp/".$uniqconf.".call";
        $myfile =  fopen($uniq1,"w");
                 $channel = "Local/5556@stoprecord";$context = "stoprecord";$extension="5556";
                fwrite($myfile,"channel:$channel\n");
                fwrite($myfile,"Extension:$extension\n");
                fwrite($myfile,"context:$context\n");
                fwrite($myfile,"waitTime:300\n");
                fwrite($myfile,"Setvar:monitorin=$audioin\n");
                fwrite($myfile,"Setvar:monitorcust=$audiocust\n");
                fclose($myfile);
                exec("/bin/mv $uniq1 /var/spool/asterisk/outgoing");
 
                   //system("/usr/bin/rm -rf $audioin");  
                   //exec("/usr/bin/sox --ignore-length $audiocust $audioin");    
	//}
   }
 function wavDur($file)
{

       $type=substr($file,-3);
       if($type=="gsm")
       {
       $fp = fopen($file, 'r');
       $size_in_bytes = filesize($file);
       $sec = ceil($size_in_bytes/1650);
       $minutes = intval(($sec / 60) % 60);
       $seconds = intval($sec % 60);
      // return str_pad($minutes,2,"0", STR_PAD_LEFT).":".str_pad($seconds,2,"0", STR_PAD_LEFT);
	  return str_pad($sec,2,"0", STR_PAD_LEFT);
       }


}


?>

