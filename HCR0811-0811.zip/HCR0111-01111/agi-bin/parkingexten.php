#!/usr/bin/php 
<?php
include_once("/var/lib/asterisk/agi-bin/phpagi.php");
$agi = new AGI();

$phone = $argv[1];

$conn = mysqli_connect("localhost","root","Hal0o(0m@72427242","asterisk");

$rtyu = mysqli_query($conn,"select channel from vicidial_manager where callerid = '$phone'");
$rti = mysqli_fetch_array($rtyu);
$chan = "Channel: ".$rti['channel'];

$agi->verbose("++++++++++++++++$chan+++++++++++++");

$qwe = mysqli_query($conn,"select cmd_line_d from vicidial_manager where cmd_line_b='$chan'");

$wer = mysqli_fetch_array($qwe);
$route = trim($wer[cmd_line_d]);
$agi->verbose("++++++++++++++++$route+++++++++++++");
if(substr($route,-4)=='8301'){
$res = mysqli_query($conn,"select callid,ispark from parking_nag where callid='$phone'");
if(mysqli_num_rows($res)==0){
mysqli_query($conn,"insert into parking_nag(callid,ispark)values('$phone','park')");
mysqli_query($conn,"update vicidial_log set wrap='park' where callid='$phone'");
}
else{
mysqli_query($conn,"update vicidial_log set wrap='' where callid='$phone'");
}
}
?>
