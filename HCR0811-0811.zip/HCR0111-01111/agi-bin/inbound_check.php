#!/usr/bin/php -q
<?php
require('/var/lib/asterisk/agi-bin/phpagi.php');
require('dbconnect_mysqli.php');
$agi = new AGI();
$no  = $argv[1];
$date =date('Y-m-d H:i:s');
$sel1 = "select user from vicidial_list where phone_number = '$no' and user !='VDCL' and user != '$no'";
$agi->verbose("========".$sel1);
$res1 = mysqli_query($link,$sel1);
$row1 =  mysqli_fetch_array($res1);

$user = $row1[0];
$agi->verbose("User:".$user);


if($user != '')
{
$sel2 = "select status  from vicidial_live_agents  where user ='$user'";
$res2 = mysqli_query($link,$sel2);
$row2 =  mysqli_fetch_array($res2);
$status = $row2[0];
$agi->verbose("Status:".$status);
if($status == 'READY')
{
$agi->verbose("Agent is Ready to take calls");
$grp = 'AGENTDIRECT';
$agi->set_variable("grp", $grp);
$agi->set_variable("user", $user);
}
else
{
$sel = "insert into miss_did(sticky_user,phone,dateT,call_status) values('$user','$no','$date','Agent Not Ready')";
$agi->verbose("================".$sel);
$res = mysqli_query($link,$sel);
$agi->hangup();	
}
}
else
{
$agi->verbose("New Lead pass number to a free agent");
$sel_status = "select user  from vicidial_live_agents  where ((status ='READY') or (status ='PAUSED') or (status ='PAUSED'))";
$res_status = mysqli_query($link,$sel_status);
$row_status =  mysqli_fetch_array($res_status);
$user = $row_status[0];
$grp = 'AGENTDIRECT';
$agi->set_variable("grp", $grp);
$agi->set_variable("user", $user);


}
?>
