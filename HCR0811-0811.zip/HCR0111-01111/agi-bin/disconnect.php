#!/usr/bin/php -q
<?php
 GLOBAL $agi;
require_once('dbconnect_mysqli.php');
require('/var/lib/asterisk/agi-bin/phpagi.php');
$agi = new AGI();
$chan = $argv[1];
//$agi->verbose("=======".$channel);
$stmt = "select extrachannel from hang_conf where channel = '$chan'";
$rslt = mysqli_query($link,$stmt);
$rowcount=mysqli_num_rows($rslt);
if($rowcount == 0)
{
$stmt = "select channel from hang_conf where extrachannel = '$chan'";

$rslt = mysqli_query($link,$stmt);
}
$row  = mysqli_fetch_array($rslt);
    $socket = fsockopen("127.0.0.1","5038", $errno, $errstr, 10);
    $wrets = fread($socket,30);
    fputs($socket, "Action: Login\r\n");
    fputs($socket, "UserName:cron\r\n");
    fputs($socket, "Secret:1234\r\n\r\n");
    fputs($socket, "Action:Redirect\r\n");
    fputs($socket, "Channel:$row[0]\r\n");
    fputs($socket, "Context:hang2\r\n");
    fputs($socket, "Exten:2233\r\n");
    fputs($socket, "Priority:1\r\n\r\n");
    fputs($socket, "Action: Logoff\r\n\r\n");
    while (!feof($socket)) {
    $wrets .= fread($socket,8192 );
    }
   fclose($socket);
	//echo $wrets;


?>
