#!/usr/bin/php 
<?php
include_once("/var/lib/asterisk/agi-bin/phpagi.php");
$agi = new AGI();

$exten = trim(substr($argv[1],-10));
$callid = $argv[3];

$conn = mysqli_connect("localhost","root","Hal0o(0m@72427242","asterisk");
$fg = $callid;

$vb = explode(' ',$fg);

 $rt = trim(str_replace('"','',$vb[0]));

$agi->verbose("+++++++++$rt+++$callid+++++$exten+++");

mysqli_query($conn,"update vicidial_log set wrap='park' where callid='$rt'");

$agi->verbose("+++++++++$rt+++$callid+++++$exten++parked+");
?>
