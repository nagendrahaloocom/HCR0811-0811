#!/usr/bin/php 
<?php
include_once("/var/lib/asterisk/agi-bin/phpagi.php");
$agi = new AGI();

$exten = trim(substr($argv[1],-10));
$callid = $argv[2];

$conn = mysqli_connect("localhost","root","Hal0o(0m@72427242","asterisk");
$fg = $callid;

$vb = explode(' ',$fg);

 $rt = trim(str_replace('"','',$vb[0]));

$agi->verbose("+++++++++$rt+++$callid+++++$exten+++");

$req = mysqli_query($conn,"select channel from vicidial_manager where callerid = '$rt'");
$der = mysqli_fetch_array($req);
$chan = $der['channel'];
mysqli_query($conn,"update vicidial_log set callid = '$rt',chan='$chan' where phone_number='$exten' order by call_date desc limit 1");
?>
