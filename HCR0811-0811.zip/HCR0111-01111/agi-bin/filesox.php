#!/usr/bin/php 
<?php
include_once("/var/lib/asterisk/agi-bin/phpagi.php");
$agi = new AGI();

$audioin = $argv[1];
$audiocust = $argv[2];
system("/usr/bin/rm -rf $audioin");
                   exec("/usr/bin/sox --ignore-length $audiocust $audioin");

$ft = substr($audiocust,0,-3)."gsm";
$rem = substr($audiocust,0,-9)."*";
date_default_timezone_set("Asia/Kolkata");
$date = "/home/RECORDINGS/ORIG/".date("y-m-d");
/*if (file_exists($date)){
system("/usr/bin/cp -r $ft /home/RECORDINGS/ORIG/");}else{
system("/usr/bin/mkdir $date");
system("/usr/bin/cp -r $ft /home/RECORDINGS/ORIG/");}*/

exec("/usr/bin/rm -rf $rem");


