#!/usr/bin/php 
<?php
include_once("/var/lib/asterisk/agi-bin/phpagi.php");
$agi = new AGI();

$chan = $argv[1];



$audio = $argv[2];
$callerid = $argv[3];
$ocallerid = $argv[4];
$park = $argv[5];

$dispo = $argv[7];

if(substr($callid,0,1)=='S'){
$wrap = "wrapupincoming.php";
}else{$wrap = "wrapup.php";}
if(strlen($callerid)==12){
$wrap = "wrapupincoming.php";
}else{$wrap = "wrapup.php";}


$conn = mysqli_connect("localhost","root","Hal0o(0m@72427242","asterisk");
$rty = mysqli_query($conn,"select wrap from vicidial_log where callid='$audio'");
$row = mysqli_fetch_array($rty);
$parky = $row['wrap'];


$agi->verbose("+++++++++++++++++++parkstatus++++++$parky+++++++++++");

if(strlen($ocallerid)==12){$callerid = substr($ocallerid,-10);}
$agi->verbose("=======$audio+++++++++++++++");
$agi->verbose("=======$chan++++++++++++");
$afg = substr($audio,0,1);
$agi->verbose("=======$afg++++++++++++");
$cgh = substr($chan,-1);
$agi->verbose("=======$cgh+++++++++++++++");

if(substr($audio,0,1)=='M'){
if(substr($chan,-2)==';2'){}else{
//if(strlen($callerid) == '10'){}else{
$agi->verbose("=====firstcurl++++$audio++++$parking+++++++++");
exec("/usr/bin/curl -k 'http://localhost/Haloo_Voicelogs/$wrap?callid=$audio&park=$parky'");}}
else{
if(substr($chan,-1)=='2'){
$fv = explode(" ",$audio);
$br= str_replace('"','',$fv[0]);

$agi->verbose("==========+++$br++++voicelogger+++++++++++++");
exec("/usr/bin/curl -k 'http://localhost/Haloo_Voicelogs/filemonitor.php?audio=$br'");}}


if((strlen($callerid) == '10')||(strlen($callerid) == '12')){
$agi->verbose("=====secondcurl+++++$audio++++$parking++++++++");
$agi->verbose("+++++++++++++++$callerid+++++++++++++++++sssdsd++++++++++");
exec("/usr/bin/curl -k 'http://localhost/Haloo_Voicelogs/$wrap?phone=$callerid&callid=$audio&park=$parky'");}
?>
