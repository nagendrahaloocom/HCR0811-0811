#!/usr/bin/php 
<?php
include_once("/var/lib/asterisk/agi-bin/phpagi.php");
$agi = new AGI();

$chan = $argv[1];

if(substr($chan,0,7)=="SIP/JIO"){$cli="yes";}else{$cli="no";}


$audio = $argv[2];
$callerid = $argv[3];
$ocallerid = $argv[4];
$park = $argv[5];
if($park=='yes'){exit;}
if(strlen($ocallerid)==12){$callerid = substr($ocallerid,-10);}
$agi->verbose("=======$audio+++++++++++++++");
$agi->verbose("=======$chan++++++++++++");
$afg = substr($audio,0,1);
$agi->verbose("=======$afg++++++++++++");
$cgh = substr($chan,-1);
$agi->verbose("=======$cgh+++++++++++++++");

if(substr($audio,0,1)=='M'){
if(substr($chan,-2)==';2'){}else{
$agi->verbose("=====firstcurl++++$audio++++$parking+++++++++");
exec("/usr/bin/curl -k 'http://localhost/Haloo_Voicelogs/wrapup.php?callid=$audio&park=$parking&nag=yes&cli=$cli'");}}
else{
if(substr($chan,-1)=='2'){
$fv = explode(" ",$audio);
$br= str_replace('"','',$fv[0]);

$agi->verbose("==========+++$br++++voicelogger+++++++++++++");
exec("/usr/bin/curl -k 'http://localhost/Haloo_Voicelogs/filemonitor.php?audio=$br'");}}


if((strlen($callerid) == '10')||(strlen($callerid) == '12')){
$agi->verbose("=====secondcurl+++++$audio++++$parking++++++++");
$agi->verbose("+++++++++++++++$callerid+++++++++++++++++sssdsd++++++++++");
exec("/usr/bin/curl -k 'http://localhost/Haloo_Voicelogs/wrapup.php?phone=$callerid&callid=$audio&park=$parking&nag='");}

?>
