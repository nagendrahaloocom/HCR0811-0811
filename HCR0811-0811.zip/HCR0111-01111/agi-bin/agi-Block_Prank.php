#!/usr/bin/php -q
<?php
	
	require("phpagi.php");
	GLOBAL $agi;
	$agi = new AGI();


        $callereID=$agi->request[agi_callerid];


	$servername = "localhost";
$username = "cron";
$password = "1234";

// Create connection
$conn = mysqli_connect($servername, $username, $password,'asterisk');

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

	$sqlQry="SELECT * FROM vicidial_dnc WHERE phone_number ='$callereID'";
	$exeQry=mysqli_query($conn,$sqlQry);
	$count=mysqli_num_rows($exeQry);
	$agi->verbose("====".$sqlQry);
	if($count==0)
	{
		$agi->verbose("Number not in DNC");
		exit;
	}
	else
	{
		$agi->verbose("Number in DNC. Disconnecting");
		$agi->hangup();
	}
?>
